using Microsoft.AspNetCore.Mvc;
using Rotas.Aereas.Application;
using Rotas.Aereas.Application.Interfaces;
using Rotas.Aereas.Domain.Entities;

namespace Rotas.Aereas.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RotasController : ControllerBase
    {
        private IRotaService _service;
        public RotasController(IRotaService service)
        {
            _service = service;
        }

        /// <summary>
        /// Lista todas as rotas.
        /// </summary>
        /// <returns>rotas cadastradas</returns>
        /// <response code="200">Retorna todas as rotas cadastradas</response>
        [HttpGet]
        public async Task<ActionResult> Get()
        {
            var response = await _service.GetRotas();
            return new OkObjectResult(response);
        }
        /// <summary>
        /// Busca a rota de viagem de menor valor entre 2 aeroportos.
        /// </summary>
        /// <returns>Melhor rota de viagem</returns>
        /// <response code="200">Retorna a rota de menor valor total entre 2 aeroportos</response>
        [HttpGet("Melhor-Rota")]
        public async Task<ActionResult> GetMelhorRota([FromQuery] int aeroportoOrigem, [FromQuery] int aeroportoDestino)
        {

            var response = await _service.GetMelhorRota(aeroportoOrigem, aeroportoDestino);
            return new OkObjectResult(response);
        }


        /// <summary>
        /// Adiciona uma nova rota.
        /// </summary>
        /// <returns>rotas cadastradas</returns>
        /// <response code="200">Retorna uma lista atualizada de todas as rotas</response>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] PatchRotaRequest request)
        {
            var response = await _service.AddRotas(request);
            return new OkObjectResult(response);
        }

        /// <summary>
        /// Atualiza uma rota ja existente.
        /// </summary>
        /// <returns>rotas cadastradas</returns>
        /// <response code="200">Retorna uma lista atualizada de todas as rotas</response>
        [HttpPatch]
        public async Task<ActionResult> Patch([FromBody] PatchRotaRequest request)
        {
            var response = await _service.PatchRotas(request);
            return new OkObjectResult(response);

        }

        /// <summary>
        /// Deleta uma rota existente.
        /// </summary>
        /// <returns>rotas cadastradas</returns>
        /// <response code="200">Retorna uma lista atualizada de todas as rotas</response>
        [HttpDelete]
        public async Task<ActionResult> Delete([FromQuery] int idRota)
        {
            var response = await _service.DeleteRotas(idRota);

            return new OkObjectResult(response);

        }
    }
}
