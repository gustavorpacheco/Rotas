﻿using Rotas.Aereas.Domain.Entities;

namespace Rotas.Aereas.Domain.MelhorRota
{
    public class MelhorRota
    {
        public List<RotaAerea> Rotas { get; set; }
        public decimal ValorTotal { get; set; }
    }
}
