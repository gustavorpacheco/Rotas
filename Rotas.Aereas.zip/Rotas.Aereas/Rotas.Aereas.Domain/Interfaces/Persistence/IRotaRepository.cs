﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rotas.Aereas.Domain.Entities;

namespace Rotas.Aereas.Domain.Interfaces.Persistence
{
    public interface IRotaRepository
    {
        Task<List<RotaAerea>> GetRotas();
        Task<List<RotaAerea>> GetRotasAeroporto(int aeportoId);
        Task<List<RotaAerea>> AddRota(RotaAerea rota);
        Task<List<RotaAerea>> PatchRota(RotaAerea rota);
        Task<List<RotaAerea>> DeleteRotas(int idRota);
    }
}
