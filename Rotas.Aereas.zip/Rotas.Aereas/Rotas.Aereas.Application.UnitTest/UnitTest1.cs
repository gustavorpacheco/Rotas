
using Moq;
using Rotas.Aereas.Domain.Entities;
using Rotas.Aereas.Domain.Interfaces.Persistence;
using Rotas.Aereas.Domain.MelhorRota;

namespace Rotas.Aereas.UnitTest
{
    public class BuscarRotaServiceTests
    {
        private readonly Mock<IRotaRepository> _repository;
        private readonly Mock<BuscarRotaService> _rotaService;

        public BuscarRotaServiceTests()
        {
            _repository = new Mock<IRotaRepository>();
            _rotaService = new Mock<BuscarRotaService>(_repository.Object);

            var rotas = new List<RotaAerea>()
            {
                new RotaAerea(){Id = 1, IdAeroportoDestino = 2, IdAeroportoOrigem = 1, NomeAeroportoDestino = "teste 1", NomeAeroportoOrigem = "teste 1", Valor = 10},
                new RotaAerea(){Id = 2, IdAeroportoDestino = 3, IdAeroportoOrigem = 2, NomeAeroportoDestino = "teste 3", NomeAeroportoOrigem = "teste 2", Valor = 10},
                new RotaAerea(){Id = 3, IdAeroportoDestino = 1, IdAeroportoOrigem = 3, NomeAeroportoDestino = "teste 2", NomeAeroportoOrigem = "teste 1", Valor = 50},
                new RotaAerea(){Id = 4, IdAeroportoDestino = 3, IdAeroportoOrigem = 1, NomeAeroportoDestino = "teste 2", NomeAeroportoOrigem = "teste 1", Valor = 30}
            };
            _repository.Setup(s => s.GetRotasAeroporto(1)).ReturnsAsync(rotas.FindAll(r=> r.IdAeroportoOrigem == 1));
            _repository.Setup(s => s.GetRotasAeroporto(2)).ReturnsAsync(rotas.FindAll(r=> r.IdAeroportoOrigem == 2));
            _repository.Setup(s => s.GetRotasAeroporto(3)).ReturnsAsync(rotas.FindAll(r=> r.IdAeroportoOrigem == 3));
        }


        [Fact]
        public async Task BuscarMelhorRota_DeveRetornarMelhorRota()
        {
            var rotas = new List<RotaAerea>()
            {
                new RotaAerea(){Id = 1, IdAeroportoDestino = 2, IdAeroportoOrigem = 1, NomeAeroportoDestino = "teste 1", NomeAeroportoOrigem = "teste 1", Valor = 10},
                new RotaAerea(){Id = 4, IdAeroportoDestino = 3, IdAeroportoOrigem = 1, NomeAeroportoDestino = "teste 2", NomeAeroportoOrigem = "teste 1", Valor = 30}
            };

            var retorno = await _rotaService.Object.EncontrarMelhorRota(rotas, 3);

            Assert.NotNull(retorno);
            Assert.Equal(20, retorno.ValorTotal);
        }
    }
}