﻿using Rotas.Aereas.Domain.Entities;
using Rotas.Aereas.Domain.Interfaces.Persistence;
using System.Text.Json;
using Microsoft.Extensions.Caching.Memory;

namespace Rotas.Aereas.Infrastructure.Persistence
{
    public class RotaRepository : IRotaRepository
    {
        private readonly IMemoryCache _memoryCache;
        public RotaRepository(IMemoryCache memoryCache) 
        {
            _memoryCache = memoryCache;
        }

        public async Task<List<RotaAerea>> GetRotas()
        {
            if(!_memoryCache.TryGetValue("rotas", out List<RotaAerea> rotas))
            {
                string rawJson = await File.ReadAllTextAsync("RotaRepository.json");

                rotas = JsonSerializer.Deserialize<List<RotaAerea>>(rawJson);
                _memoryCache.Set("rotas", rotas);
            }
            return rotas;
        }

        public async Task<List<RotaAerea>> AddRota(RotaAerea rota)
        {
            List<RotaAerea> rotas = await GetRotas();
            rota.Id = rotas[rotas.Count - 1].Id + 1;
            rotas.Add(rota);
            File.WriteAllText("RotaRepository.json", JsonSerializer.Serialize(rotas));
            _memoryCache.Set("rotas", rotas);
            return rotas;
        }

        public async Task<List<RotaAerea>> DeleteRotas(int IdRota)
        {
            List<RotaAerea> rotas = await GetRotas();
            int indexParaRemover = rotas.FindIndex(rota => rota.Id == IdRota);
            if (indexParaRemover == -1)
            {
                throw new Exception("Rota não existe");
            }
            rotas.RemoveAt(indexParaRemover);
            File.WriteAllText("RotaRepository.json", JsonSerializer.Serialize(rotas));
            _memoryCache.Set("rotas", rotas);
            return rotas;
        }

        public async Task<List<RotaAerea>> GetRotasAeroporto(int aeportoId)
        {
            List<RotaAerea> rotas = await GetRotas();
            rotas = rotas.FindAll(rota => rota.IdAeroportoOrigem == aeportoId);
            return rotas;
        }

        public async Task<List<RotaAerea>> PatchRota(RotaAerea rota)
        {
            List<RotaAerea> rotas = await GetRotas();
            int indexRota = rotas.FindIndex(r => r.Id == rota.Id);
            if (indexRota == -1)
            {
                throw new Exception("Rota não existe");
            }
            rotas[indexRota] = rota;
            File.WriteAllText("RotaRepository.json", JsonSerializer.Serialize(rotas));
            _memoryCache.Set("rotas", rotas);
            return rotas;
        }
    }
}
