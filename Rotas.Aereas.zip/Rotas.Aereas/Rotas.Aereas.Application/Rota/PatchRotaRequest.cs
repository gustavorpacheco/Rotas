﻿using Rotas.Aereas.Domain.Entities;

namespace Rotas.Aereas.Application
{
    public class PatchRotaRequest : RotaAerea
    {
       
    }
}
