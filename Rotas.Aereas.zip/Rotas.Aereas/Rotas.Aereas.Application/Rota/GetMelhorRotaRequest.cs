﻿using Rotas.Aereas.Domain.Entities;
using Microsoft.CSharp.RuntimeBinder;

namespace Rotas.Aereas.Application
{
    public class GetMelhorRotaRequest
    {
        public int AeroportoOrigem { get; set; }
        public int AeroportoDestino { get; set; }
    }
}
