﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rotas.Aereas.Domain.Entities;
using Rotas.Aereas.Application.Interfaces;
using Rotas.Aereas.Domain.Interfaces.Persistence;
using Rotas.Aereas.Domain.MelhorRota;

namespace Rotas.Aereas.Application.Rota
{

    public class RotaService : IRotaService
    {
        private readonly IRotaRepository _rotaRepository;

        private readonly BuscarRotaService _buscarRotaService;

        public RotaService(IRotaRepository rotaRepository, BuscarRotaService buscarRotaService)
        {
            _rotaRepository = rotaRepository;
            _buscarRotaService = buscarRotaService;
        }

        public async Task<List<RotaAerea>> PatchRotas(PatchRotaRequest rotaRequest)
        {
            List<RotaAerea> response = new List<RotaAerea>();
            response = await _rotaRepository.PatchRota(rotaRequest);

            return response;
        }

        public async Task<List<RotaAerea>> GetRotas()
        {
            List<RotaAerea> response = new List<RotaAerea>();
            response = await _rotaRepository.GetRotas();

            return response;
        }

        public async Task<List<RotaAerea>> AddRotas(PatchRotaRequest rotaRequest)
        {
            List<RotaAerea> response = new List<RotaAerea>();
            response = await _rotaRepository.AddRota(rotaRequest);

            return response;
        }

        public async Task<List<RotaAerea>> DeleteRotas(int idRota)
        {
            List<RotaAerea> response = new List<RotaAerea>();
            response = await _rotaRepository.DeleteRotas(idRota);

            return response;
        }

        public async Task<MelhorRota> GetMelhorRota(int aeroportoOrigem, int aeroportoDestino)
        {
            List<RotaAerea> rotas = await _rotaRepository.GetRotasAeroporto(aeroportoOrigem);
            var response = await _buscarRotaService.EncontrarMelhorRota(rotas, aeroportoDestino);

            return response;

        }
       
    }
}
