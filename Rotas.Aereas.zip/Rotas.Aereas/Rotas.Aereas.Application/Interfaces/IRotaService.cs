﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rotas.Aereas.Domain.Entities;
using Rotas.Aereas.Domain.MelhorRota;

namespace Rotas.Aereas.Application.Interfaces
{
    public interface IRotaService
    {
        Task<List<RotaAerea>> GetRotas();
        Task<MelhorRota> GetMelhorRota(int aeroportoOrigem, int aeroportoDestino);
        Task<List<RotaAerea>> AddRotas(PatchRotaRequest rotaRequest);
        Task<List<RotaAerea>> PatchRotas(PatchRotaRequest rotaRequest);
        Task<List<RotaAerea>> DeleteRotas(int idRota);
    }
}
