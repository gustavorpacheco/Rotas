import { TestBed } from '@angular/core/testing';

import { RotasAereasService } from './rotas-aereas.service';

describe('RotasAereasService', () => {
  let service: RotasAereasService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RotasAereasService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
