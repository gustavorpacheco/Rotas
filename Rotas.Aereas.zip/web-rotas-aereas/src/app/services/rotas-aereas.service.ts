import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Rota } from '../models/melhor-rota.model';

@Injectable({
  providedIn: 'root'
})
export class RotasAereasService {

  private readonly applicationAddres = "https://localhost:7208/"

  constructor(private httpClient: HttpClient) { }

  BuscarMelhorRota(aeroportoOrigem: number, aeroportoDestino: number) {
    return this.httpClient.get<any>(this.applicationAddres +`Rotas/Melhor-Rota?aeroportoOrigem=${aeroportoOrigem}&aeroportoDestino=${aeroportoDestino}`);
  }

  GetRotas() {
    return this.httpClient.get<any>(this.applicationAddres +`Rotas`);
  }

  AddRota(rota: Rota) {
    return this.httpClient.post<any>(this.applicationAddres +`Rotas`, rota);
  }

  PatchRota(rota: Rota) {
    return this.httpClient.patch<any>(this.applicationAddres +`Rotas`, rota);
  }

  DeleteRota(idRota: number) {
    return this.httpClient.delete<any>(this.applicationAddres +`Rotas?idRota=${idRota}`);
  }
}

