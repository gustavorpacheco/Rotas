export interface MelhorRotaModel {
  rotas: Array<Rota> ;
  valorTotal: number ;
}

export interface Rota {
  id?: number,
  idAeroportoOrigem: number,
  nomeAeroportoOrigem: string,
  idAeroportoDestino: number,
  nomeAeroportoDestino: string,
  valor: number
}
