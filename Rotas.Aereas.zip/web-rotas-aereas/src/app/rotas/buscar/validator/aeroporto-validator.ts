import { AbstractControl, ValidationErrors, ValidatorFn } from "@angular/forms";

export function validarAeroporto(origem: string, destino: string): ValidatorFn {
    return (group:AbstractControl) : ValidationErrors | null => {
      const controleOrigem = group.get(origem);
      const controleDestino = group.get(destino);


    if (!controleOrigem || !controleDestino) {
        return null;
    }

    if (!controleOrigem || !controleDestino) {
        return null;
    }

      return controleOrigem.value === controleDestino.value ? {camposIguais: true} : null;
    }
}
