import { RotasAereasService } from './../../services/rotas-aereas.service';
import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { validarAeroporto } from './validator/aeroporto-validator';
import { MelhorRotaModel } from '../../models/melhor-rota.model';

@Component({
  selector: 'app-rotas-buscar',
  templateUrl: './rotas.buscar.component.html',
  styleUrls: ['./rotas.buscar.component.scss']
})
export class RotasBuscarComponent {

  listaAeroportos = [
    {
      id: 1, nome: "GRU"
    },
    {
      id: 2, nome: "BRC"
    },
    {
      id: 3, nome: "SCL"
    },
    {
      id: 4, nome: "CDG"
    },
    {
      id: 5, nome: "ORL"
    }
  ];

  melhorRota: any = null;
  stringRota = "";

  escalaAereaForm = new FormGroup({
    aeroportoOrigem: new FormControl(1, Validators.required),
    aeroportoDestino: new FormControl(2, Validators.required),
  },
  {
    validators: validarAeroporto('aeroportoDestino', 'aeroportoOrigem')
  })

  constructor(private rotasAereasService: RotasAereasService) {}

  buscar() {
    if(this.escalaAereaForm.invalid) {
      return;
    }

    this.rotasAereasService.BuscarMelhorRota(this.escalaAereaForm.controls.aeroportoOrigem.value!, this.escalaAereaForm.controls.aeroportoDestino.value!).subscribe( (res: MelhorRotaModel) => {
      this.melhorRota = res;
      this.stringRota = res.rotas[0].nomeAeroportoOrigem;
      res.rotas.forEach(rota => {
        this.stringRota += " - " + rota.nomeAeroportoDestino;
      }, () => window.alert("Ocorreu um erro inesperado")
);
    });
  }
}
