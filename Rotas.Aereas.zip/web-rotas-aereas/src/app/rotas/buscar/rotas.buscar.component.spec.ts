import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RotasBuscarComponent } from './rotas.buscar.component';

describe('RotasBuscarComponent', () => {
  let component: RotasBuscarComponent;
  let fixture: ComponentFixture<RotasBuscarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RotasBuscarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RotasBuscarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
