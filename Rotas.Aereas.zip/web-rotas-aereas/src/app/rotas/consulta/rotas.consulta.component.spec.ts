import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RotasConsultaComponent } from './rotas.consulta.component';

describe('RotasConsultaComponent', () => {
  let component: RotasConsultaComponent;
  let fixture: ComponentFixture<RotasConsultaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RotasConsultaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RotasConsultaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
