import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Rota } from './../../models/melhor-rota.model';
import { RotasAereasService } from './../../services/rotas-aereas.service';
import { Component, OnInit } from '@angular/core';
import { validarAeroporto } from '../buscar/validator/aeroporto-validator';

@Component({
  selector: 'app-rotas-consulta',
  templateUrl: './rotas.consulta.component.html',
  styleUrls: ['./rotas.consulta.component.scss']
})
export class RotasConsultaComponent implements OnInit{

  listaAeroportos = [
      {
        id: 1, nome: "GRU"
      },
      {
        id: 2, nome: "BRC"
      },
      {
        id: 3, nome: "SCL"
      },
      {
        id: 4, nome: "CDG"
      },
      {
        id: 5, nome: "ORL"
      }
  ];
  rotas: Array<Rota> = [];
  atualizarRotaForm = new FormGroup({
    rotaSelecionada: new FormControl(0, Validators.required),
    aeroportoOrigem: new FormControl(0, Validators.required),
    aeroportoDestino: new FormControl(0, Validators.required),
    valor: new FormControl(0, Validators.required),
  },
  {
    validators: validarAeroporto('aeroportoDestino', 'aeroportoOrigem')
  });

  deletarRotaForm = new FormGroup({
    rotaSelecionada: new FormControl(0, Validators.required),
  });

  adicionarRota = new FormGroup({
    aeroportoOrigem: new FormControl(0, Validators.required),
    aeroportoDestino: new FormControl(0, Validators.required),
    valor: new FormControl(0, Validators.required)
  },
  {
    validators: validarAeroporto('aeroportoDestino', 'aeroportoOrigem')
  });

  constructor(private rotasAereasService: RotasAereasService){}

  ngOnInit(): void {
    this.rotasAereasService.GetRotas().subscribe( (res: Array<Rota>) => {
      this.rotas = res;
    })
  }

  setValoresInputsAtualizacao(event: any) {
    const index = Number(event.target.value - 1);
    const rota = this.rotas[index];
    this.atualizarRotaForm.controls.aeroportoDestino.setValue(rota.idAeroportoDestino);
    this.atualizarRotaForm.controls.aeroportoOrigem.setValue(rota.idAeroportoOrigem);
    this.atualizarRotaForm.controls.valor.setValue(rota.valor);
  }

  cadastrarRota() {
    if(this.adicionarRota.invalid) {
      return;
    }
    const nomeAeroportoDestino = this.listaAeroportos.find(a => a.id == this.adicionarRota.controls.aeroportoDestino.value)?.nome;
    const nomeAeroportoOrigem = this.listaAeroportos.find(a => a.id == this.adicionarRota.controls.aeroportoOrigem.value)?.nome;
    const rota: Rota = {
      idAeroportoDestino: this.adicionarRota.controls.aeroportoDestino.value,
      idAeroportoOrigem: this.adicionarRota.controls.aeroportoOrigem.value,
      valor: this.adicionarRota.controls.valor.value,
      nomeAeroportoDestino,
      nomeAeroportoOrigem
    } as Rota;

    this.rotasAereasService.AddRota(rota).subscribe( (res: Array<Rota>) => {
      this.rotas = res;
      window.alert("Rota cadastrada com sucesso");
    }, () => {
      window.alert("Ocorreu um erro inesperado");
    });
  }

  atualizarRota() {
    if(this.atualizarRotaForm.invalid) {
      return;
    }
    const nomeAeroportoDestino = this.listaAeroportos.find(a => a.id == this.atualizarRotaForm.controls.aeroportoDestino.value)?.nome;
    const nomeAeroportoOrigem = this.listaAeroportos.find(a => a.id == this.atualizarRotaForm.controls.aeroportoOrigem.value)?.nome;
    const rota: Rota = {
      idAeroportoDestino: this.atualizarRotaForm.controls.aeroportoDestino.value,
      idAeroportoOrigem: this.atualizarRotaForm.controls.aeroportoOrigem.value,
      valor: this.atualizarRotaForm.controls.valor.value,
      nomeAeroportoDestino,
      nomeAeroportoOrigem,
      id: this.atualizarRotaForm.controls.rotaSelecionada.value
    } as Rota;

    this.rotasAereasService.PatchRota(rota).subscribe( (res: Array<Rota>) => {
      this.rotas = res;
      window.alert("Rota atualizada com sucesso");
    }, () => {
      window.alert("Ocorreu um erro inesperado");
    });
  }

  deletarRota() {
    if(this.deletarRotaForm.invalid) {
      return;
    }
    const idRota = Number(this.deletarRotaForm.controls.rotaSelecionada?.value);
    this.rotasAereasService.DeleteRota(idRota).subscribe( (res: Array<Rota>) => {
      this.rotas = res;
      window.alert("Rota atualizada com sucesso");
    }, () => {
      window.alert("Ocorreu um erro inesperado");
    });
  }
}
