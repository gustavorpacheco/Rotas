import { Component } from '@angular/core';

@Component({
  selector: 'app-rotas',
  templateUrl: './rotas.component.html',
  styleUrls: ['./rotas.component.scss']
})
export class RotasComponent {

  public esconderAdmin = true;
  public esconderBusca = false;

  exibirAdmin() {
    this.esconderAdmin = false;
    this.esconderBusca = true;
  }

  exibirBusca() {
    this.esconderAdmin = true;
    this.esconderBusca = false;
  }
}
